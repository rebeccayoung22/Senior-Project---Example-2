<!DOCTYPE html>
<head>

<title> "Sea" SS </title>
<link href='style.css' rel='stylesheet'/>

<script src='jquery-1.10.1.min.js'></script>

</head>
<body>

<header>
	<div class='center'>
		<span id='logoarea'>Sea SS</span>
		<a href='index.php'><span class='buttons'>Log In</span></a>
	</div>
</header>

<?php

	
	
	if(isSet($_POST['username'])&&isSet($_POST['password'])&&isSet($_POST['password2'])&&isSet($_POST['email'])){
		if(!empty($_POST['username'])&&!empty($_POST['password'])&&!empty($_POST['password2'])&&!empty($_POST['email'])){
			
			if($_POST['password'] == $_POST['password2']){
				$database = mysqli_connect('localhost', 'root', '', 'WebUsers');
				$result = mysqli_query($database, "INSERT INTO Users(Username, Password, Email)VALUES ('".mysql_real_escape_string(trim($_POST['username']))."','".mysql_real_escape_string(sha1(trim($_POST['password']) . 'dinos149!'))."','".mysql_real_escape_string(trim($_POST['email']))."')");
				//$row = mysqli_fetch_array($result);
				echo '<script> window.location = "index.php";</script>';
			} else {
				echo '<script>$(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#email").val("'.$_POST['email'].'");$("#pahint").show();});</script>';
			}
			
		} else if(empty($_POST['username'])&&empty($_POST['password'])&&empty($_POST['password2'])&&empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#email").addClass("formInvalid");$("#pass2").addClass("formInvalid");$("#use").addClass("formInvalid");$("#pass").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['username'])&&empty($_POST['password'])&&empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#email").addClass("formInvalid");$("#use").addClass("formInvalid");$("#pass").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['username'])&&empty($_POST['password2'])&&empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#email").addClass("formInvalid");$("#pass2").addClass("formInvalid");$("#use").addClass("formInvalid"); </script>';
		} else if(empty($_POST['password'])&&empty($_POST['password2'])&&empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#email").addClass("formInvalid");$("#pass2").addClass("formInvalid");$("#pass").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['username'])&&empty($_POST['password'])&&empty($_POST['password2'])){
			echo '<script> $(document).ready(function(){$("#email").val("'.$_POST['email'].'");$("#pass2").addClass("formInvalid");$("#use").addClass("formInvalid");$("#pass").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['username'])&&empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#email").addClass("formInvalid");$("#use").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['password'])&&empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#email").addClass("formInvalid");$("#pass").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['password2'])&&empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#email").addClass("formInvalid");$("#pass2").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['password2'])&&empty($_POST['username'])){
			echo '<script> $(document).ready(function(){$("#email").val("'.$_POST['email'].'");$("#use").addClass("formInvalid");$("#pass2").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['username'])&&empty($_POST['password'])){
			echo '<script> $(document).ready(function(){$("#email").val("'.$_POST['email'].'");$("#use").addClass("formInvalid");$("#pass").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['password'])&&empty($_POST['password2'])){
			echo '<script> $(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#email").val("'.$_POST['email'].'");$("#pass").addClass("formInvalid");$("#pass2").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['username'])){
			echo '<script> $(document).ready(function(){$("#email").val("'.$_POST['email'].'");$("#use").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['email'])){
			echo '<script> $(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#email").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['password'])){
			echo '<script> $(document).ready(function(){$("#email").val("'.$_POST['email'].'");$("#use").val("'.$_POST['username'].'");$("#pass").addClass("formInvalid");});</script>';
		} else if(empty($_POST['password2'])){
			echo '<script> $(document).ready(function(){$("#email").val("'.$_POST['email'].'");$("#use").val("'.$_POST['username'].'");$("#pass2").addClass("formInvalid");});</script>';
		} 
	}
	
	
?>

<style>
	#email, #pass2 {
		margin: 0;
		margin-top: 2px;
		border-radius: 0;
	}
	
	#email {
		background: white url('Mail.png') no-repeat;
		background-size: 20px;
		background-position: 10px;
		border-top-left-radius: 0; 
		border-top-right-radius: 0; 
		margin: 0;
		margin-top: 2px;
	}
	
	#pass2 {
		background: white url('Lock.png') no-repeat;
		background-size: 20px;
		background-position: 10px;
		border-top-left-radius: 0; 
		border-top-right-radius: 0; 
		margin: 0;
		margin-top: 2px;
	}
	
	#pahint {
		width: 185px;
	}
</style>

<div id='formcontainer'>

	<form method='POST' action='<?php echo $_SERVER['PHP_SELF']; ?>'>
	
	<h2>Sign Up</h2>
	<input class='write' id='use' type='text' name='username' placeholder='Username'/><br>
	<input class='write' id='email' type='text' name='email' placeholder='Email'/><br>
	<input class='write' id='pass2' type='password' name='password2' placeholder='Password'/><br>
	<input class='write' id='pass' type='password' name='password' placeholder='Retype Password'/><br>
	<div id="pahint" class="hint"><div class="tri"></div>Passwords Are Not Same</div>
	<input id='submit' type='submit' value='Submit'/>
	
	</form>

</div>

</body>
</html>