<!DOCTYPE html>
<head>

<title> "Sea" SS </title>
<link href='style.css' rel='stylesheet'/>

<script src='jquery-1.10.1.min.js'></script>

</head>
<body>

<header>
	<div class='center'>
		<span id='logoarea'>Sea SS</span>
		<a href='signup.php'><span class='buttons'>Sign Up</span></a>
	</div>
</header>

<?php

	session_start();
	
	if(isSet($_POST['username'])&&isSet($_POST['password'])){
		if(!empty($_POST['username'])&&!empty($_POST['password'])){
			$database = mysqli_connect('localhost', 'root', '', 'WebUsers');
			$result = mysqli_query($database, "SELECT * FROM Users WHERE Username = '".mysql_real_escape_string(trim($_POST['username']))."'");
			$row = mysqli_fetch_array($result);
			
			if($row['Password'] == mysql_real_escape_string(sha1(trim($_POST['password']) . 'dinos149!'))){
				$_SESSION['username'] = $_POST['username'];
				echo '<div class="overtake">You logged in foo (A.K.A. '.$_SESSION['username'].')!</div>';
			} else if($row['Username'] == mysql_real_escape_string($_POST['username'])){
				echo '<script>$(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#phint").show();});</script>';
			} else {
				echo '<script>$(document).ready(function(){$("#uhint").show();});</script>';
			}
			
			//while ($row = mysqli_fetch_array($result)){
				//echo $row[0]." - ".$row[1]."<br>";
				//if($_POST['username'] == $row[0]&&$_POST['password'] == $row[1]){
					
					//break;
				//} 
				
			//}
			
		} else if(empty($_POST['username'])&&empty($_POST['password'])){
			echo '<script> $(document).ready(function(){$("#use").addClass("formInvalid");$("#pass").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['username'])){
			echo '<script> $(document).ready(function(){$("#use").addClass("formInvalid");}); </script>';
		} else if(empty($_POST['password'])){
			echo '<script> $(document).ready(function(){$("#use").val("'.$_POST['username'].'");$("#pass").addClass("formInvalid");});</script>';
		}
	}
	
	
?>

<div id='formcontainer'>

	<form method='POST' action='<?php echo $_SERVER['PHP_SELF']; ?>'>
	
	<h2>Log In</h2>
	<input class='write' id='use' type='text' name='username' placeholder='Username'/><br>
	<div id="uhint" class="hint"><div class="tri"></div>Wrong Username</div>
	<input class='write' id='pass' type='password' name='password' placeholder='Password'/><br>
	<div id="phint" class="hint"><div class="tri"></div>Wrong Password</div>
	<input id='submit' type='submit' value='Submit'/>
	<input id='check' type='checkbox'/> Stay Logged In<br>
	
	</form>

</div>

</body>
</html>